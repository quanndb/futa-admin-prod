import api, { createQueryParams } from "./api"
import type { PageRequest, PageResponse } from "./types"
import { showSuccess } from "@/lib/toast-utils"

export interface TransitPoint {
  id: string
  name: string
  address: string
  hotline: string
  type: "PLACE" | "STATION" | "OFFICE" | "TRANSPORT"
  createdAt: string
  lastModifiedAt: string
}

export interface CreateTransitPointDto {
  name: string
  address: string
  hotline: string
  type: "PLACE" | "STATION" | "OFFICE" | "TRANSPORT"
}

export interface UpdateTransitPointDto {
  name?: string
  address?: string
  hotline?: string
  type?: "PLACE" | "STATION" | "OFFICE" | "TRANSPORT"
}

const TransitPointService = {
  getPage: async (pageRequest: PageRequest): Promise<PageResponse<TransitPoint>> => {
    try {
      const queryParams = createQueryParams(pageRequest)
      const response = await api.get<PageResponse<TransitPoint>>(`/transit-points?${queryParams}`)
      return response.data
    } catch (error) {
      // Lỗi đã được xử lý bởi interceptor
      throw error
    }
  },

  getById: async (id: string): Promise<TransitPoint> => {
    try {
      const response = await api.get<TransitPoint>(`/transit-points/${id}`)
      return response.data
    } catch (error) {
      // Lỗi đã được xử lý bởi interceptor
      throw error
    }
  },

  create: async (transitPoint: CreateTransitPointDto): Promise<TransitPoint> => {
    try {
      const response = await api.post<TransitPoint>("/transit-points", transitPoint)
      showSuccess(`Đã thêm điểm trung chuyển ${transitPoint.name} thành công`)
      return response.data
    } catch (error) {
      // Lỗi đã được xử lý bởi interceptor
      throw error
    }
  },

  update: async (id: string, transitPoint: UpdateTransitPointDto): Promise<TransitPoint> => {
    try {
      const response = await api.put<TransitPoint>(`/transit-points/${id}`, transitPoint)
      showSuccess(`Đã cập nhật điểm trung chuyển ${transitPoint.name} thành công`)
      return response.data
    } catch (error) {
      // Lỗi đã được xử lý bởi interceptor
      throw error
    }
  },

  delete: async (id: string): Promise<void> => {
    try {
      await api.delete(`/transit-points/${id}`)
      showSuccess("Đã xóa điểm trung chuyển thành công")
    } catch (error) {
      // Lỗi đã được xử lý bởi interceptor
      throw error
    }
  },
}

export default TransitPointService
