import api from "./api"
import { showSuccess } from "@/lib/toast-utils"

interface LoginCredentials {
  email: string
  password: string
}

interface LoginResponse {
  token: string
  user: {
    id: string
    email: string
    name: string
    role: string
  }
}

const AuthService = {
  login: async (credentials: LoginCredentials): Promise<LoginResponse> => {
    try {
      const response = await api.post<LoginResponse>("/iam/auth/login", credentials)
      showSuccess("Đăng nhập thành công")
      return response.data
    } catch (error) {
      // Lỗi đã được xử lý bởi interceptor
      throw error
    }
  },

  logout: async (): Promise<void> => {
    try {
      await api.post("/iam/auth/logout")
      showSuccess("Đăng xuất thành công")
    } catch (error) {
      console.error("Lỗi đăng xuất:", error)
      // Không hiển thị lỗi khi đăng xuất, vì chúng ta vẫn muốn xóa dữ liệu local
    } finally {
      // Xóa local storage bất kể phản hồi API
      localStorage.removeItem("authToken")
      localStorage.removeItem("isAuthenticated")
    }
  },

  getCurrentUser: async () => {
    try {
      const response = await api.get("/iam/auth/me")
      return response.data
    } catch (error) {
      // Lỗi đã được xử lý bởi interceptor
      throw error
    }
  },
}

export default AuthService
